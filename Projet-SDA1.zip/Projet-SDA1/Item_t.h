#pragma once

#include "Mot_s.h"

/// @brief Type devant �tre adapter en fonction des besoins de l'application.
typedef Mot Item;