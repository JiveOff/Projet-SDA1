#pragma once

struct Mot {
	char mot[31];
};